import React from 'react'

const Footer = () => {
  return (
    <div>
      Thsi is footer
    </div>
  )
}

export default Footer
