import React from 'react'

const AccountSetting = () => {
  return (
    <div>
      
    </div>
  )
}

export default AccountSetting
