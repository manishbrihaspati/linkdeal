import React, { useState } from "react";
import LayoutWrapper from "../../Layout/LayoutWrapper";

import SwitchBox from "../../../components/Settings/SwitchBox";
import ToolTip from "../../../components/Settings/ToolTip";
import { Radio } from "@mui/joy";
const ConnectSetting = () => {
    const [checked, setChecked] = useState(false);
    return (
        <LayoutWrapper title="Connect Settings">
            <div className="row">
                <div className="col-md-6">
                    <h5 className="my-4">
                        <b>Connection Settings</b>
                    </h5>
                    <div className="card p-3">
                        <div className="row mt-3">
                            <div className="col-md-6">
                                <h6 className="d-inline">
                                    <b>Send Request After meetings</b>
                                </h6>
                            </div>
                            <div
                                className="col-md-6 row"
                                style={{ justifyContent: "right" }}
                            >
                                <div className="switch w-auto ">
                                    {/* <Switch color="" size="lg" /> */}
                                    <SwitchBox
                                        checked={checked}
                                        setChecked={setChecked}
                                    />
                                </div>
                                <div className="warninfo w-auto">
                                    <ToolTip text="hello " />
                                </div>
                            </div>
                        </div>

                        <div className="row mt-3">
                            <div className="col-md-6">
                                <h6 className="d-inline">
                                    <b>Freequency Once Daily </b>
                                </h6>
                            </div>
                            <div
                                className="col-md-6 row"
                                style={{ justifyContent: "right" }}
                            >
                                <div className="switch w-auto ">
                                    {/* <Switch color="" size="lg" /> */}
                                    <SwitchBox
                                        checked={checked}
                                        setChecked={setChecked}
                                    />
                                </div>
                                <div className="warninfo w-auto">
                                    <ToolTip text="hello " />
                                </div>
                            </div>
                        </div>
                        <div className="row mt-3">
                            <div className="col-md-6">
                                <h6 className="d-inline">
                                    <b>Freequency - After Minutes (mins) : </b>
                                </h6>
                            </div>
                            <div
                                className="col-md-6 row"
                                style={{ justifyContent: "right" }}
                            >
                                <div className="switch w-auto ">
                                    {/* <Switch color="" size="lg" /> */}
                                    <SwitchBox
                                        checked={checked}
                                        setChecked={setChecked}
                                    />
                                </div>
                                <div className="warninfo w-auto">
                                    <ToolTip text="hello " />
                                </div>
                            </div>
                        </div>
                        <div className="row mt-3">
                            <div className="col-md-6">
                                <h6 className="d-inline">
                                    <b>Send non-meeting attendees requests</b>
                                </h6>
                            </div>
                            <div
                                className="col-md-6 row"
                                style={{ justifyContent: "right" }}
                            >
                                <div className="switch w-auto ">
                                    {/* <Switch color="" size="lg" /> */}
                                    <SwitchBox
                                        checked={checked}
                                        setChecked={setChecked}
                                    />
                                </div>
                                <div className="warninfo w-auto">
                                    <ToolTip text="hello " />
                                </div>
                            </div>
                        </div>
                        <div className="row mt-3">
                            <div className="col-md-6">
                                <h6 className="d-inline">
                                    <b>Send when meeting attendees accepts</b>
                                </h6>
                            </div>
                            <div
                                className="col-md-6 row"
                                style={{ justifyContent: "right" }}
                            >
                                <div className="switch w-auto ">
                                    {/* <Switch color="" size="lg" /> */}
                                    <SwitchBox
                                        checked={checked}
                                        setChecked={setChecked}
                                    />
                                </div>
                                <div className="warninfo w-auto">
                                    <ToolTip text="hello " />
                                </div>
                            </div>
                        </div>
                        <div className="row mt-3">
                            <div className="col-md-6">
                                <h6 className="d-inline">
                                    <b>Remove pending connection monthly </b>
                                </h6>
                            </div>
                            <div
                                className="col-md-6 row"
                                style={{ justifyContent: "right" }}
                            >
                                <div className="switch w-auto ">
                                    {/* <Switch color="" size="lg" /> */}
                                    <SwitchBox
                                        checked={checked}
                                        setChecked={setChecked}
                                    />
                                </div>
                                <div className="warninfo w-auto">
                                    <ToolTip text="hello " />
                                </div>
                            </div>
                        </div>
                        <div className="row mt-3">
                            <div className="col-md-6">
                                <h6 className="d-inline">
                                    <b>Send connection summary by email </b>
                                </h6>
                            </div>
                            <div
                                className="col-md-6 row"
                                style={{ justifyContent: "right" }}
                            >
                                <div className="switch w-auto ">
                                    {/* <Switch color="" size="lg" /> */}
                                    <SwitchBox
                                        checked={checked}
                                        setChecked={setChecked}
                                    />
                                </div>
                                <div className="warninfo w-auto">
                                    <ToolTip text="hello " />
                                </div>
                            </div>
                        </div>
                        <div className="row mt-3">
                            <div className="col-md-4">
                                <h6 className="d-inline">
                                    <b>Freequency : </b>
                                </h6>
                            </div>
                            <div
                                className="col-md-8 row"
                                style={{ justifyContent: "space-evenly" }}
                            >
                                <Radio
                                    sx={{
                                        width: "auto",
                                        display: "inline",
                                        padding: "0px 5px",
                                    }}
                                    color="danger"
                                    orientation="horizontal"
                                    label="Daily"
                                    size="md"
                                    name="radio-buttons"
                                />
                                <Radio
                                    sx={{
                                        width: "auto",
                                        display: "inline",
                                        padding: "0px 5px",
                                    }}
                                    color="danger"
                                    orientation="horizontal"
                                    label="Weekly"
                                    size="md"
                                    name="radio-buttons"
                                />
                                <Radio
                                    sx={{
                                        width: "auto",
                                        display: "inline",
                                        padding: "0px 5px",
                                    }}
                                    color="danger"
                                    orientation="horizontal"
                                    label="Monthly"
                                    size="md"
                                    name="radio-buttons"
                                />
                            </div>
                        </div>
                    </div>
                    <div className="mt-4">
                        <button className="btn btn-connect">
                            Reset Connection Settings{" "}
                        </button>
                    </div>
                </div>
            </div>
        </LayoutWrapper>
    );
};

export default ConnectSetting;
