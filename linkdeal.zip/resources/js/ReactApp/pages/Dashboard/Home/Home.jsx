import React from 'react'
import LayoutWrapper from '../../Layout/LayoutWrapper'

const Home = () => {
  return (
    <LayoutWrapper>
      This is home
    </LayoutWrapper>
  )
}

export default Home
