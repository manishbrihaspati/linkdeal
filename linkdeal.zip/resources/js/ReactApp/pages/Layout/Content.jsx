// LayoutWrapper.js
import React, { Suspense, useEffect, startTransition } from "react";
import Header from "../../components/Layout/Header";
import ContentRoutes from "../../routes/ContentRoutes";

// import Header from "../../components/Layout/Header";
import Sidebar from "../../components/Layout/Sidebar";
import ContentArea from "./ContentArea";
import { LinearProgress } from "@mui/joy";
// import Content from "./Content";

const Loading = () => {
    return <LinearProgress />;
};

const Content = () => {
    return (
        <div className="content">
            <Sidebar />
            <div className="content_area ">
                <Header />
                <Suspense fallback={<Loading />}>
                    <ContentRoutes />
                </Suspense>
            </div>
        </div>
    );
};

export default Content;
