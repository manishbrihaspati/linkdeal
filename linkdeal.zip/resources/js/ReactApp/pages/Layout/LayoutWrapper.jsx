// LayoutWrapper.js
import React, { startTransition, useEffect } from "react";

const Loading = () => {
    return <div> loading </div>;
};

const LayoutWrapper = ({ children, title }) => {
    useEffect(() => {
        startTransition(() => {
            // Update the title when the component mounts or when pageTitle changes
            document.title = title || "Linkdeal";
        });

        return () => {
            // Reset the title when the component unmounts
            document.title = "Linkdeal";
        };
    }, [title]);

    return (
        <div className="main_content mt-3">{children}</div>
        );
    };
    
    export default LayoutWrapper;