import React, { Suspense } from "react";
import ContentRoutes from "../../routes/ContentRoutes";

const Loading = () => {
    console.log('loading')
    return <div> loading </div>;
};

const ContentArea = ({ children }) => {
    return (
        <Suspense fallback={<Loading />}>
            <ContentRoutes />
        </Suspense>
    );
};

export default ContentArea;
